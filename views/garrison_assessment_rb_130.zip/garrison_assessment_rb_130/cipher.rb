class Cipher
  def self.encode(string)
    alphabet = ("a".."z").to_a
    characters = get_clean_characters(string, alphabet)
    words_array = characters.chars.each_slice(5).to_a
    words_array.map! do |word|
      [encode_segment(word, alphabet)]
    end
    words_array.flatten.join(" ")
  end

  def self.encode_segment(string, alphabet)
    result = ""
    string.each do |character|
      if alphabet.include?(character)
        current_index = alphabet.index(character)
        result_index = (current_index * -1) - 1
        result += alphabet[result_index]
      else result += character
      end
    end
    result
  end

  def self.get_clean_characters(string, alphabet)
    characters = downcase_letters(string, alphabet).join
    characters.gsub(/[ \W]/, "")
  end

  def self.downcase_letters(string, alphabet)
    string.chars.map do |character|
      if alphabet.include?(character.downcase)
        character.downcase
      else character
      end
    end
  end
end
